'use strict';

module.exports.hello = async (event) => {
  return {
    statusCode: 200,
    headers: { 'Access-Control-Allow-Origin': '*' },
    body: JSON.stringify(
      {
        message: 'Hola desde Lambda Serverless!',
        time: new Date().toISOString(),
      },
      null,
      2
    ),
  };
};
